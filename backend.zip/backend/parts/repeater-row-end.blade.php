  <div class="col-xs-12">
    <button type="button" class="btn {{$remove}} btn-danger btn-sm btn-remove-field @if( $remove <= 0 ) no-show @endif" data-id="1"><i class="fa fa-close" id=""></i> {{$params->button_d}}</button>
    <hr>
  </div>
</div>