<div class="col-lg-{{$params->width}} form-group relative">
  <label for="nome">{{$params->title}}</label>
  <textarea class="form-control textarea editor-video" placeholder="" name="{{$field}}">{{$value}}</textarea>
</div>