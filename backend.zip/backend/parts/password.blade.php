<div class="col-lg-{{$params->width}} form-group">
  <label for="nome">{{$params->title}}</label>
  <input type="password" class="form-control" id="{{$field}}" placeholder="{{$params->title}}..." name="{{$field}}">
</div>