<div class="col-lg-{{$params->width}} form-group">
  <label for="nome">{{$params->title}}</label>
  <input type="email" class="form-control" id="{{$field}}" value="{{ $value }}" placeholder="{{$params->title}}..." name="{{$field}}">
</div>